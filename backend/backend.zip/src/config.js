module.exports = {
    'MONGO_URI': 'mongodb+srv://apsing2462001:mEqbEivQaFepZWer@quizapp.gxdptue.mongodb.net/?retryWrites=true&w=majority&appName=quizapp'
}